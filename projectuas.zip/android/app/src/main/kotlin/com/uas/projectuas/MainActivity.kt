package com.uas.projectuas

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
